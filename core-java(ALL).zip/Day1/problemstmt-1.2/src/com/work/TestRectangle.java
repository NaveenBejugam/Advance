package com.work;

import java.util.Scanner;

public class TestRectangle {
	
		public static int length;
		public static int breadth;
		public static int area;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		
		//1st object
		TestRectangle test1= new TestRectangle();
		Scanner one=new Scanner(System.in);
		System.out.println("Enter length and breadth for rectangle 1: ");
		test1.length=one.nextInt();
		test1.breadth=one.nextInt();
		test1.area= length * breadth;
		System.out.println("Area of rectangle 1: "+ test1.area);
		
		//2nd object
		TestRectangle test2= new TestRectangle();
		Scanner two=new Scanner(System.in);
		System.out.println("Enter length and breadth for rectangle 2: ");
		test2.length=two.nextInt();
		test2.breadth=two.nextInt();
		test2.area= length * breadth;
		System.out.println("Area of rectangle 2: "+ test2.area);
		
		//3rd object
		TestRectangle test3= new TestRectangle();
		Scanner three=new Scanner(System.in);
		System.out.println("Enter length and breadth for rectangle 3: ");
		test3.length=three.nextInt();
		test3.breadth=three.nextInt();
		test3.area= length * breadth;
		System.out.println("Area of rectangle 3: "+ test3.area);
		
		//4th object
		TestRectangle test4= new TestRectangle();
		Scanner four=new Scanner(System.in);
		System.out.println("Enter length and breadth for rectangle 4: ");
		test4.length=four.nextInt();
		test4.breadth=four.nextInt();
		test4.area= length * breadth;
		System.out.println("Area of rectangle 4: "+ test4.area);
		
		//5th object
		TestRectangle test5= new TestRectangle();
		Scanner five=new Scanner(System.in);
		System.out.println("Enter length and breadth for rectangle 5: ");
		test5.length=five.nextInt();
		test5.breadth=five.nextInt();
		test5.area= length * breadth;
		System.out.println("Area of rectangle 5: "+ test5.area);
		
	}

}
