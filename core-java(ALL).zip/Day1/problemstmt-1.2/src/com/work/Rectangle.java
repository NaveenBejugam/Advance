package com.work;

class Rectangle{
	
	public int Length;
	public int Breadth;
	public int Area;
	
	//Default Constructor
	public Rectangle() 
	{
		
	}

	//Parameterized Constructor
	public Rectangle(int Length, int Breadth) {
		this.Length = Length;
		this.Breadth = Breadth;
	}
	
	//Area
	public void printArea() {
		Area = Length * Breadth;
		System.out.println("Area of Rectangle : " + Area);
	}

	public void printData() {
		System.out.println("Length of Rectangle is : " + Length);
		System.out.println("Breadth of Rectangle is : " + Breadth);
	
	}
	
	
		public static void main(String[] args) {
			Rectangle rect = new Rectangle(9, 4);
			
			rect.printData();
			rect.printArea();
	
		}
	}
	
