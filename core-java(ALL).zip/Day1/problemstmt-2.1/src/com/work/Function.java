package com.work;

import java.util.Scanner;

public class Function {
	
	public static void main(String[] args) {
		
		  String str, rev = "";
	      Scanner fun = new Scanner(System.in);
	 
	      System.out.println("Enter a string:");
	      str = fun.nextLine();
	      System.out.println("===============");
	 
	      int length = str.length();
	      System.out.println("Length of String is:"+length);
	      
	      System.out.println("===============");
	       
	      String check = str.toUpperCase();
	      System.out.println("String in Uppercase:"+check);
	      
	      System.out.println("===============");
	 
	      for ( int i = length - 1; i >= 0; i-- )
	      {
	         rev = rev + str.charAt(i);
	      }
	 
	      if (str.equals(rev))
	         System.out.println(str+" is a palindrome");
	      else
	         System.out.println(str+" is not a palindrome");
	 
	}

	

}
