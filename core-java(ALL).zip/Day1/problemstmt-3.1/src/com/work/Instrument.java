package com.work;

public abstract class Instrument 
{
	public abstract void Play();
}
