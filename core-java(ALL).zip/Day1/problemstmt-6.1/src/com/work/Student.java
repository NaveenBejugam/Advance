package com.work;

import java.util.ArrayList;


public class Student {

	public static void main(String args[])
	{ 
		
	     ArrayList<String> students=new ArrayList<String>();  
	     students.add("Amar");
	     students.add("Akbar");
	     students.add("Anthony");
	      
	      if (students.contains("Anthony"))
	            System.out.println("Anthony exists in the ArrayList");
	      else
	            System.out.println("Anthony does not exist in the ArrayList");
	      
	      if (students.contains("Marcus"))
	            System.out.println("Marcus exists in the ArrayList");
	      else
	            System.out.println("Marcus does not exist in the ArrayList");
	}
	
}
