package com.work;

public class NameNotFoundException {
	
	 public String validname()
     {
          return ("Name is not Valid..Please Re-Enter the Name");
     }

}
