package com.work;

public class Platforms {

	public static int Platform(int ari[], int dep[], int n) {

		int platform = 1, result = 1;
		int i = 1, j = 0;

		for (i = 0; i < n; i++) {

			platform = 1;

			for (j = i + 1; j < n; j++) {

				if ((ari[i] >= ari[j] && ari[i] <= dep[j]) || (ari[j] >= ari[i] && ari[j] <= dep[i]))
					platform++;
			}

			result = Math.max(result, platform);
		}

		return result;
	}

	public static void main(String[] args) {
		int arr[] = { 900, 940, 950, 1100, 1500, 1800 };
		int dep[] = { 910, 1200, 1120, 1130, 1900, 2000 };
		int n = 6;
		System.out.println("Minimum Number of Platforms Required = " + Platform(arr, dep, n));
	}

}
