package com.work;

public class Medicine {
	public void displayLabel() {
		System.out.println("Company : Pharma");
		System.out.println("Address : Hyderabad");
	}
}

class Tablet extends Medicine {
	public void displayLabel() {
		System.out.println("See before you use");
	}
}

class Syrup extends Medicine {
	public void displayLabel() {
		System.out.println("Consumption by required amount");
	}
}

class Ointment extends Medicine {
	public void displayLabel() {
		System.out.println("for external use only");
	}
}
