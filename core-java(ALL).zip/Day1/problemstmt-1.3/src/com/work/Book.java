package com.work;

public class Book
{
	  String BookName;
      int BookPrice;
    
    
     public void setBookName(String BookName)
    {
        this.BookName=BookName;
    }
    
    public String getBookName()
    {
        return this.BookName;
    }
    
    public void setBookPrice(int bookPrice)
    {
        this.BookPrice=bookPrice;
    }
    
    public int getBookPrice()
    {
        return this.BookPrice;
    }
	
}
