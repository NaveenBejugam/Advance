package com.work;

import java.util.Scanner;

public class BookTest 
{
	public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the Book name1:");
        String bookname1=sc.nextLine();
        System.out.println("Enter the Book name2:");
        String bookname2=sc.nextLine();
        
        System.out.println("Enter the price of Book1:");
        int price1=sc.nextInt();
        System.out.println("Enter the price of Book2:");
        int price2=sc.nextInt();
        sc.nextLine();
        
        
        Book obj1=new Book();
        obj1.setBookName(bookname1);
        obj1.setBookPrice(price1);
        System.out.println("Book1 Details");
        System.out.println("Book Name-1:"+obj1.getBookName());
        System.out.println("Book Price :"+obj1.getBookPrice());
        
        
        
        Book obj2=new Book();
        obj2.setBookName(bookname2);
        obj2.setBookPrice(price2);
        System.out.println("Book2 Details");
        System.out.println("Book Name-2 :"+obj2.getBookName());
        System.out.println("Book Price :"+obj2.getBookPrice());
       
       
    }
	
	
	
	
}

