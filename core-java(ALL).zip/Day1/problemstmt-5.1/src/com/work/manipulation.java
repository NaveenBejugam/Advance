package com.work;

public class manipulation {

	public static void main(String[] args) {

		String text = "JAVA is Simple";
		
		
		String  upper = text.toUpperCase();			// to UpperCase
		System.out.println("In UPPER case : "+upper);
		
		System.out.println("=============");
		
		String lower = text.toLowerCase();			// to LowerCase
		System.out.println("In LOWER case"+lower);
		
		System.out.println("=============");

		String[] words = text.split("\\s");		 	// 1st words of letter
		for (String w : words) {
			System.out.print(w.charAt(0));
			System.out.print(" ");
		}
		System.out.println(" ");
		
		System.out.println("=============");

		String[] words1 = text.split("\\s"); // Change order
		for (String w : words1) {
			System.out.println(w);
		}

		System.out.println("=============");
		
		// String Builder reverse
		StringBuilder str = new StringBuilder("JAVA is Simple");

		
		System.out.println("String : " + str.toString());
		StringBuilder reverse = str.reverse();
		System.out.println("Reverse String : " + reverse.toString());

		System.out.println("=============");
		System.out.println("length of string: " + text.length());		// Total Length
	}
}
