package com.work;

class p8_1

{

	private int x;

	public p8_1(int X) {
		x = X;
	}

	public int GetX() {
		return (x);
	}

	public p8_1(p8_1 s) {
		this.x = s.GetX();
	}

}

class Printer implements Runnable

{

	private p8_1 p8_1;

	Printer(p8_1 s) {
		p8_1 = new p8_1(s);
	}

	public void run()

	{

		System.out.println(p8_1.GetX());

	}

}

class Counter implements Runnable

{

	private int N;

	public Counter(int n) {
		N = n;
	}

	public int GetN() {
		return (N);
	}

	public void run()

	{

		for (int iLoop = 1; iLoop <= N; iLoop++)

		{

			p8_1 storage = new p8_1(iLoop);

			Printer printer = new Printer(storage);

			Thread.yield();

			printer.run();

		}

	}

}

class ThreadCounter

{

	public static void main(String args[])

	{

		Counter counter = new Counter(25);

		counter.run();

	}

}