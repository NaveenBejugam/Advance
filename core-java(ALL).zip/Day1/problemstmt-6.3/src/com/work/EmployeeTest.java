package com.work;

import java.util.LinkedList;

public class EmployeeTest {
	public static void main(String[] args) {
		LinkedList<String> list=new LinkedList<String>();
		
		list.add("Abc");
		list.add("Xyz");
		list.add("Pqr");
		
		System.out.println("Size "+list.size());
		list.add("");
		
		System.out.println(list);
		
		System.out.println(list.get(2));
		
		list.add(4,"Lmn");
		System.out.println(list);
		list.removeFirst();
		list.removeLast();
		System.out.println(list);
	}

}
