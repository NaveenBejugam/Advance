package com.work;

import java.util.*;

public class Even {
	public static void main(String[] args)
	{
		Scanner even= new Scanner(System.in);
		System.out.print("Enter value n : "+"\n" );
		int num = even.nextInt();
		for (int i = 0; i <= num; i++)
		{
			if (i % 2 == 0)
				System.out.print(i + "  ");

		}

		System.out.println();
	}

}
