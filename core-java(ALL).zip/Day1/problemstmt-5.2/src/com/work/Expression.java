package com.work;

public class Expression {
	
	public static void main(String[] args) {
		
		
		String expression= (" 23  +  45 -  (  343  /  12 ) ");
		String[] exp=expression.split(" ");
		
		for(String value:exp){  
			System.out.println(value); 
			
		}
	}

	}