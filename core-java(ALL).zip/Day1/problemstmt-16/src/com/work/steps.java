package com.work;

import java.util.Scanner;

public class steps {



    static int climb(int n)
    {
        if (n <= 1)
            return n;
        {
        return climb(n - 1) + climb(n - 2);
    }}
 
  
    static int countWays(int s)
    {
        return climb(s + 1);
    }
 
       public static void main(String args[]) {
    
    	Scanner step=new Scanner(System.in);
    System.out.println("Enter the Number");
    int n=step.nextInt();
    
    {
        
        System.out.println("Number of ways = " + countWays(n));
    }
} }
