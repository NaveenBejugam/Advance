package com.work;


import java.util.Scanner;

public class Charstring {
	
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the String: ");
		String str= scan.nextLine();
		int len =str.length();
		System.out.println(str);
		for (int i=0; i<len;i++)
		{
			char s= str.charAt(0);
			String s1=str.substring(1);
			String s2=s1+s;
			System.out.println(s2);
			str=s2;
		}
		
	}
	
	
}
