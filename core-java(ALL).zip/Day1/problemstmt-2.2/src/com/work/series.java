package com.work;

public class series {
	
	public static void main(String[] args) {

	    int i = 1, n = 15, a = 1, b= 3;
	    System.out.println(" Series till " + n );

	    while (i <= n) {
	      System.out.print(a + " ");

	      int c = a+ b;
	      a = b;
	      b = c;

	      i++;
	    }
	  }
	}



